﻿function setupTableForMobile() {

    try {
        if ($(window).width() <= 400) {
            $('table').each(function () {
                var table = $(this);
                var head = table.find('thead th');
                var rows = table.find('tbody tr').clone();

                // create new table
                var newtable = $('<table class="gfmtb" style="width: 100%;"><tbody></tbody></table>');

                var newtable_tbody = newtable.find('tbody');

                rows.each(function (i) {
                    var cols = $(this).find('td');
                    var classname = i % 2 ? 'gfmtbeven' : 'gfmtbodd';
                    cols.each(function (k) {
                        var new_tr = $('<tr class="' + classname + '"></tr>').appendTo(newtable_tbody);
                        new_tr.append(head.clone().get(k));
                        new_tr.append($(this));
                    });
                });

                $(this).after(newtable);
                table.hide();
            });

        }
    }
    catch (errtb) {
        //alert(errtb);
    }
}